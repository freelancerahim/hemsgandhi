<!doctype html>
<html>

<!-- Mirrored from workathome2day.com/cash/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Jan 2020 05:39:47 GMT -->

<head>
    <script type='text/javascript' src='../../cdn.clickmagick.com/misc/js/cm_subids.js'></script>
    <script type="text/javascript">
        function showHide() {
            var div = document.getElementById("hidden_div");
            var div2 = document.getElementById("hidden_div2");
            if (div2.style.visibility == "hidden") {
                div2.style.visibility = "visible";
                div2.style.display = "block";
                div.style.display = "none";
            }
            if (div.style.visibility == "visible") {
                div.style.visibility = "hidden";
            }
        }

        function showHide2() {
            var div2 = document.getElementById("hidden_div2");
            var div3 = document.getElementById("hidden_div3");
            if (div3.style.visibility == "hidden") {
                div3.style.visibility = "visible";
                div3.style.display = "block";
                div2.style.display = "none";
            }
            if (div2.style.visibility == "visible") {
                div2.style.visibility = "hidden";
            }
        }

        function showHide3() {
            var div3 = document.getElementById("hidden_div3");
            var div4 = document.getElementById("hidden_div4");
            if (div4.style.visibility == "hidden") {
                div4.style.visibility = "visible";
                div4.style.display = "block";
                div3.style.display = "none";
            }
            if (div3.style.visibility == "visible") {
                div3.style.visibility = "hidden";
            }
        }
    </script>
    <style>
        .tooltip-inner {
            max-width: 200px;
            padding: .25rem .5rem;
            color: #fff;
            text-align: center;
            background-color: #000;
            border-radius: .25rem;
        }

        .tooltip .arrow {
            position: absolute;
            display: block;
            width: .8rem;
            height: .4rem;
        }

        .bs-tooltip-auto[x-placement^=right] .arrow,
        .bs-tooltip-right .arrow {
            left: 0;
            width: .4rem;
            height: .8rem;
        }

        .tooltip .arrow::before {
            position: absolute;
            content: "";
            border-color: transparent;
            border-style: solid;
        }

        .bs-tooltip-auto[x-placement^=right] .arrow::before,
        .bs-tooltip-right .arrow::before {
            right: 6px;
            border-width: .4rem .4rem .4rem 0;
            border-right-color: #000;
        }

        .pk .tooltip-inner {
            background-color: red;
        }

        .pk .arrow::before {
            border-right-color: red;
        }
    </style>
    <title>Make Fast Money Online...</title>

    <meta name="viewport" content="width=device-width; initial-scale=0.7; maximum-scale=0.7;">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript">
        function sendForm() {
            var contin = 1;
            var alertmessage = "";

            if (document.getElementById("fname").value == '') {
                alertmessage = alertmessage + "Please enter a name\n";
                contin = 0;
            }
            if (document.getElementById("email").value.indexOf("@") == -1) {
                alertmessage = alertmessage + "Please enter a valid email\n";
                contin = 0;
            }
            lcpsExitPopupOn = 0;
            if (contin == 1) document.getElementById("mainForm").submit();
            else alert(alertmessage);

        }
    </script>

    <link rel="stylesheet" href="css/cp49style.css">

    <script src="js/testmodernizr-2.js"></script>

</head>

<body>

<div id=slimcontainer class=slimcontainer>
    <hr class=space />
    <div id=main role=main class=span-13>
        <div id=headline class=span-13>
            <h2><span class="black" style="font-size: 28px;">"Make Your <u>First $500 Online</u>..."</span></h2>
            <h2><span class="red" style="font-size: 26px; color: #cc0000; background-color: #ffff00;">(100% Done For You System!)</span></h2>
        </div>
        <hr class=space />
        <div class=span-13>
            <div class=yellowjohnsonbox>
                <form id="form_sub" action="config.php" method="post">
                    <br/>

                    <div id="hidden_div" style="visibility:visible;">
                        <fieldset>
                            <legend>Income Goal Per Month</legend>
                            <div class="prepend-3 step1">
                                <p>
                                    <input id="GrCustom0" name="var1" value="$5,000 - 10,000" type="radio" checked>
                                    <label for="GrCustom0">$5,000 - 10,000</label>
                                    <br>

                                    <input id="GrCustom0" name="var1" value="$10,000 - 20,000" type="radio">
                                    <label for="GrCustom0">$10,000 - 20,000</label>
                                    <br>

                                    <input id="GrCustom0" name="var1" value="$20,000 - 50,000" type="radio">
                                    <label for="GrCustom0">$20,000 - 50,000</label>
                                    <br>

                                    <input id="GrCustom0" name="var1" value="$100,000 PLUS!" type="radio">
                                    <label for="GrCustom0">$100,000 PLUS!</label>
                                    <br>

                                    <br>
                                </p>
                            </div>
                            <a href="#" onclick="showHide()" class="next">Next...</a>
                        </fieldset>
                    </div>

                    <div style="visibility: hidden;display:none;" id="hidden_div2">
                        <fieldset>
                            <legend>Want To Get Paid Daily</legend>
                            <div class="prepend-3 step1">
                                <p>
                                    <input id=GrCustom0 type=radio name="var2" id="var1" value="Yes" checked />
                                    <label for=GrCustom0>YES! Absolutely!</label>
                                    <br/>

                                    <input id=GrCustom0 type=radio name="var2" id="var1" value="No" />
                                    <label for=GrCustom0>No</label>
                                    <br/>

                                    <br>
                                </p>
                            </div>
                            <a href="#" onclick="showHide2()" class="next">Next...</a>
                        </fieldset>
                    </div>

                    <div style="visibility: hidden;display:none;" id="hidden_div3">
                        <fieldset>
                            <legend>Want To Get Started Now</legend>
                            <div class="prepend-3 step1">
                                <p>
                                    <input id="GrCustom0" name="var3" value="YES! Let Me In!" type="radio" checked />
                                    <label for=GrCustom0>YES! Let Me In!</label>
                                    <br/>

                                    <input id=GrCustom0 type=radio name="var2" id="var1" value="No" />
                                    <label for=GrCustom0>No</label>
                                    <br/>

                                    <br>
                                </p>
                            </div>
                            <a href="#" onclick="showHide3()" class="next">Next...</a>

                        </fieldset>
                    </div>

                    <div style="visibility: hidden;display:none; position: relative;" id="hidden_div4">
                        <fieldset>
                            <legend>Let's Hit That Goal!</legend>
                            <label for="email">Enter Your Email Address</label>
                            <br>
                            <input id="email" name="3" type="email">
                            <div class="tooltip fade show bs-tooltip-right pk" role="tooltip" id="tooltip143236" x-placement="right" style=" display: none;   position: absolute;
    will-change: transform;
    top: 91px;
    right: -173px;" x-out-of-boundaries="">
                                <div class="arrow" style="top: 7px;
    "></div>
                                <div class="tooltip-inner">Email Validation Failed. Can you please try again?</div>
                            </div>
                            <div class="tooltip fade bs-tooltip-right show" role="tooltip" id="tooltip307916" x-placement="right" style=" display: none;    position: absolute;
    top: 92px;
    right: -75px;
    will-change: transform;">
                                <div class="arrow" style="top: 8px;"></div>
                                <div class="tooltip-inner">Verifying... &nbsp;<img src="img/load-verify.gif"></div>
                            </div>

                            <br>
                            <center>
                                <button class="thoughtbot" onmousedown="sendForm()" id="formbutton">Next...</button>
                            </center>
                        </fieldset>
                    </div>
                    <br>
                    <br>
                    <p class="center" align="center"><span class="black" style="font-size: 22px;">As featured on...</span><img src="img/as-seen-in-us.png" style="vertical-align:inherit;"></p>
                </form>
            </div>
        </div>
    </div>

</body>

<script>
    $(document).ready(function() {
        $status = true;
        $("#form_sub").submit(function(event) {
            $("#tooltip307916").show();
            if ($status === true) {
                event.preventDefault();
                $.ajax({
                    url: "ajax.php",
                    method: "POST",
                    data: {
                        email: $("#email").val(),
                    },
                    success: function(result) {
                        if (result == "true") {
                            $status = false;
                            $("#form_sub").submit();
                        } else {
                            $("#tooltip143236").show();
                            $("#tooltip307916").hide();
                        }
                    }
                });
            }
        });
    });
</script>
<!-- Mirrored from workathome2day.com/cash/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 04 Jan 2020 05:39:50 GMT -->

</html>